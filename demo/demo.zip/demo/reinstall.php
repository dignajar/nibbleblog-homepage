<?php

error_reporting(0);

if($_GET['up']=='date')
{
	system('rm -r -f content_bk');

	system('cp -r -p content content_bk');
}
else
{
	system('rm -r -f content');

	system('cp -r -p content_bk content');
}

?>
